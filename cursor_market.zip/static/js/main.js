// 전역 Socket.IO 연결
const socket = io();

// 메시지 수신 처리
socket.on('message', function(data) {
    // 채팅 메시지가 있는 경우에만 처리
    if (document.getElementById('chat-messages')) {
        const messagesDiv = document.getElementById('chat-messages');
        const messageElement = document.createElement('div');
        messageElement.className = 'mb-2';
        messageElement.textContent = data.message;
        messagesDiv.appendChild(messageElement);
        messagesDiv.scrollTop = messagesDiv.scrollHeight;
    }
});

// 폼 제출 전 유효성 검사
document.addEventListener('submit', function(e) {
    const form = e.target;
    if (form.tagName === 'FORM') {
        const requiredFields = form.querySelectorAll('[required]');
        let isValid = true;
        
        requiredFields.forEach(field => {
            if (!field.value.trim()) {
                isValid = false;
                field.classList.add('is-invalid');
            } else {
                field.classList.remove('is-invalid');
            }
        });
        
        if (!isValid) {
            e.preventDefault();
            alert('모든 필수 항목을 입력해주세요.');
        }
    }
});

// 가격 입력 필드 포맷팅
const priceInputs = document.querySelectorAll('input[type="number"]');
priceInputs.forEach(input => {
    input.addEventListener('input', function(e) {
        let value = e.target.value.replace(/[^0-9]/g, '');
        if (value) {
            value = parseInt(value);
            e.target.value = value;
        }
    });
});

// 모바일 메뉴 토글
const navbarToggler = document.querySelector('.navbar-toggler');
if (navbarToggler) {
    navbarToggler.addEventListener('click', function() {
        const navbarCollapse = document.querySelector('.navbar-collapse');
        navbarCollapse.classList.toggle('show');
    });
}

// 페이지 로드 시 스크롤 위치 복원
window.addEventListener('load', function() {
    if (sessionStorage.getItem('scrollPosition')) {
        window.scrollTo(0, sessionStorage.getItem('scrollPosition'));
        sessionStorage.removeItem('scrollPosition');
    }
});

// 페이지 이동 시 스크롤 위치 저장
window.addEventListener('beforeunload', function() {
    sessionStorage.setItem('scrollPosition', window.scrollY);
}); 